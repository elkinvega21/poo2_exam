import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrmPersonas extends JFrame {
    private JTextField txtDocumentoId;
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtEdad;
    private JTextField txtIdPropietario;

    public FrmPersonas() {
        setLayout(null);
        setSize(800, 600);
        setTitle("Propietario");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create labels
        JLabel lblDocumentoId = new JLabel("Documento ID:");
        lblDocumentoId.setBounds(20, 20, 100, 20);
        add(lblDocumentoId);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 50, 100, 20);
        add(lblNombre);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(20, 80, 100, 20);
        add(lblApellido);

        JLabel lblEdad = new JLabel("Edad:");
        lblEdad.setBounds(20, 110, 100, 20);
        add(lblEdad);

        JLabel lblIdPropietario = new JLabel("ID Propietario:");
        lblIdPropietario.setBounds(20, 140, 100, 20);
        add(lblIdPropietario);

        // Create text fields
        txtDocumentoId = new JTextField();
        txtDocumentoId.setBounds(130, 20, 150, 20);
        add(txtDocumentoId);

        txtNombre = new JTextField();
        txtNombre.setBounds(130, 50, 150, 20);
        add(txtNombre);

        txtApellido = new JTextField();
        txtApellido.setBounds(130, 80, 150, 20);
        add(txtApellido);

        txtEdad = new JTextField();
        txtEdad.setBounds(130, 110, 150, 20);
        add(txtEdad);

        txtIdPropietario = new JTextField();
        txtIdPropietario.setBounds(130, 140, 150, 20);
        add(txtIdPropietario);

        // Create a button to save data
        JButton btnSave = new JButton("Guardar");
        btnSave.setBounds(20, 180, 100, 30);
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve data from text fields
                String documentoId = txtDocumentoId.getText();
                String nombre = txtNombre.getText();
                String apellido = txtApellido.getText();
                int edad = Integer.parseInt(txtEdad.getText());
                int idPropietario = Integer.parseInt(txtIdPropietario.getText());

                // Save data (you can implement your own logic here)
                System.out.println("Datos guardados:");
                System.out.println("Documento ID: " + documentoId);
                System.out.println("Nombre: " + nombre);
                System.out.println("Apellido: " + apellido);
                System.out.println("Edad: " + edad);
                System.out.println("ID Propietario: " + idPropietario);
            }
        });
        add(btnSave);
    }

    public static void main(String[] args) {
        FrmPersonas pantalla = new FrmPersonas();
        pantalla.setVisible(true);
    }
}
