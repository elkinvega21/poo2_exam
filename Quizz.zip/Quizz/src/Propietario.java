public class Propietario  extends Persona{
    String Idpropietario;

    public Propietario(int documento, String nombre, String apellido, int edad, String idpropietario, String idpropietario1) {
        super(documento, nombre, apellido, edad, idpropietario);
        Idpropietario = idpropietario1;
    }
}

