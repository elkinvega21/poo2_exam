public class Persona {
    int documento;
    String nombre;
    String apellido;

    int edad;



    public Persona(int documento, String nombre, String apellido, int edad, String idpropietario) {
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;

    }
}
